import './styles/main.css';
import { createDashboard } from './modules/dashboard.js';
import { GantryScene } from './modules/gantryScene.js';
import { CycleController } from './modules/cycleController.js';

const app = document.querySelector('#app');
app.innerHTML = createDashboard();

const sceneHost = document.querySelector('#scene');
const scene = new GantryScene(sceneHost);
const controller = new CycleController(scene, {
  cycleSeconds: 28,
  totalTires: 80,
  rows: 4,
  cols: 5,
  pallets: 4
});

controller.bindUI();
scene.bindControls();

window.addEventListener('resize', () => scene.resize());
