import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

export class GantryScene {
  constructor(host) {
    this.host = host;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x06101d);
    this.camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    this.camera.position.set(15, 13, 17);
    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    host.appendChild(this.renderer.domElement);
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.target.set(0, 1.8, 0);
    this._buildLights(); this._buildFloor(); this._buildPallets(); this._buildGantry();
    this.gripper = this._buildGripper();
    this.gripperGroup = new THREE.Group(); this.gripperGroup.add(this.gripper); this.scene.add(this.gripperGroup);
    this.resize(); this.animate();
  }
  mat(color, metal=0.1, rough=.55) { return new THREE.MeshStandardMaterial({color, metalness:metal, roughness:rough}); }
  _buildLights() {
    this.scene.add(new THREE.HemisphereLight(0x9ec8ff, 0x07111f, 2.2));
    const key = new THREE.DirectionalLight(0xffffff, 3); key.position.set(5,16,9); key.castShadow=true; this.scene.add(key);
    const blue = new THREE.PointLight(0x1b7cff, 16, 35); blue.position.set(-8,5,4); this.scene.add(blue);
  }
  _buildFloor() {
    const floor = new THREE.Mesh(new THREE.BoxGeometry(25,.35,17), this.mat(0x0b1828,.1,.85)); floor.position.y=-.25; floor.receiveShadow=true; this.scene.add(floor);
    const grid = new THREE.GridHelper(24,24,0x17406a,0x0d2844); grid.position.y=-.05; this.scene.add(grid);
  }
  _buildPallets() {
    this.tireMeshes=[]; const palletXs=[-6.2,-2.05,2.1,6.25];
    palletXs.forEach((px,pi)=>{
      const base=new THREE.Mesh(new THREE.BoxGeometry(3.35,.35,7.1),this.mat(0x182b42,.25,.5)); base.position.set(px,.25,0); base.castShadow=true; base.receiveShadow=true; this.scene.add(base);
      for(let r=0;r<4;r++) for(let c=0;c<5;c++) {
        const z=-2.55+c*1.28, y=.65+r*.78;
        const tire=new THREE.Mesh(new THREE.TorusGeometry(.42,.17,12,28),this.mat(0x202b37,.1,.6)); tire.rotation.x=Math.PI/2; tire.position.set(px-.95+r*.62,y,z); tire.castShadow=true; this.scene.add(tire);
        tire.userData={pallet:pi,row:r,col:c,done:false}; this.tireMeshes.push(tire);
      }
      const label=this._label(`P${pi+1}`); label.position.set(px, .65, -3.85); this.scene.add(label);
    });
  }
  _buildGantry() {
    const steel=this.mat(0x2a425b,.7,.28), dark=this.mat(0x101b2a,.45,.35), accent=this.mat(0x1687ff,.45,.25);
    [-8.7,8.7].forEach(x=>{ const leg=new THREE.Mesh(new THREE.BoxGeometry(.45,4.2,.45),steel); leg.position.set(x,1.9,0); this.scene.add(leg); const foot=new THREE.Mesh(new THREE.BoxGeometry(1.1,.3,1.1),dark); foot.position.set(x,-.05,0); this.scene.add(foot); });
    const bridge=new THREE.Mesh(new THREE.BoxGeometry(18,.5,.55),steel); bridge.position.set(0,4.1,0); bridge.castShadow=true; this.scene.add(bridge);
    const bridge2=bridge.clone(); bridge2.position.z=1.0; bridge2.scale.x=.88; this.scene.add(bridge2);
    this.yRail=new THREE.Group(); this.yRail.position.set(0,3.72,.45); this.scene.add(this.yRail);
    const ybeam=new THREE.Mesh(new THREE.BoxGeometry(5.5,.35,.35),accent); ybeam.position.x=0; this.yRail.add(ybeam);
    const zcol=new THREE.Mesh(new THREE.BoxGeometry(.45,3.2,.45),dark); zcol.position.y=-1.6; this.yRail.add(zcol);
    this.axisVisuals={x:this.yRail,y:ybeam,z:zcol};
  }
  _buildGripper(){
    const g=new THREE.Group(); const metal=this.mat(0x90a9bd,.75,.22), green=this.mat(0x00d99a,.45,.25);
    const plate=new THREE.Mesh(new THREE.BoxGeometry(1.1,.18,.75),metal); plate.position.y=-3.15; g.add(plate);
    [-.34,.34].forEach(x=>{const jaw=new THREE.Mesh(new THREE.BoxGeometry(.12,.65,.55),green); jaw.position.set(x,-3.55,0); g.add(jaw);});
    return g;
  }
  _label(text){ const c=document.createElement('canvas'); c.width=256;c.height=80; const ctx=c.getContext('2d'); ctx.fillStyle='#071225';ctx.fillRect(0,0,256,80);ctx.fillStyle='#7cc8ff';ctx.font='bold 42px Arial';ctx.textAlign='center';ctx.fillText(text,128,54); const t=new THREE.CanvasTexture(c); const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true})); s.scale.set(1.4,.44,1); return s; }
  setPosition(x,y,z){ this.gripperGroup.position.set(x,y,z); }
  setAxes(x,y,z){ this.yRail.position.x=x; this.yRail.position.z=y; this.gripperGroup.position.y=z; }
  setGripper(open){ this.gripper.children.filter(c=>c.geometry?.type==='BoxGeometry').forEach((jaw,i)=>{ if(i>0) jaw.position.x=(i===1?-1:1)*(open?.34:.22); }); }
  cameraPreset(name){ const p={iso:[15,13,17],top:[0,22,.01],front:[0,7,22]}[name]||[15,13,17]; this.camera.position.set(...p); this.controls.target.set(0,2,0); this.controls.update(); }
  bindControls(){ document.querySelectorAll('[data-camera]').forEach(b=>b.addEventListener('click',()=>this.cameraPreset(b.dataset.camera))); }
  markDone(index){ if(this.tireMeshes[index]){ this.tireMeshes[index].material.color.set(0x00a979); this.tireMeshes[index].userData.done=true; }}
  resetTires(){ this.tireMeshes.forEach(t=>{t.material.color.set(0x202b37);t.userData.done=false;}); }
  resize(){ const w=this.host.clientWidth,h=this.host.clientHeight; this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.renderer.setSize(w,h); }
  animate(){ requestAnimationFrame(()=>this.animate()); this.controls.update(); this.renderer.render(this.scene,this.camera); }
}
