export function createDashboard() {
  return `
  <div class="app-shell">
    <header class="topbar">
      <div class="brand"><div class="brand-mark">PP</div><div><strong>JANTEK</strong><span>Picker & Placer Control</span></div></div>
      <div class="system-status"><span class="pulse"></span> SYSTEM ONLINE <b>•</b> Auto Mode</div>
      <div class="top-actions"><button class="icon-btn" id="resetBtn" title="Reset cycle">↻</button><button class="icon-btn" id="viewBtn" title="Toggle camera">◉</button><div class="avatar">OP</div></div>
    </header>

    <aside class="sidebar">
      <button class="nav-item active" data-panel="overview">⌂<span>Overview</span></button>
      <button class="nav-item" data-panel="layout">▦<span>Layout</span></button>
      <button class="nav-item" data-panel="cycle">◷<span>Cycle Monitor</span></button>
      <button class="nav-item" data-panel="alarms">⚠<span>Alarms</span></button>
      <button class="nav-item" data-panel="settings">⚙<span>Settings</span></button>
      <div class="sidebar-spacer"></div>
      <div class="mini-legend"><i></i> Live 3D<br><i class="yellow"></i> Moving<br><i class="green"></i> Complete</div>
    </aside>

    <main class="main-content">
      <section class="hero-row">
        <div><p class="eyebrow">GANTRY PICK & PLACE</p><h1>4-Pallet Tyre Placement Cell</h1><p class="subtext">80 tyre positions · 4 rows × 5 columns per pallet · target cycle time <strong>28.0 s / tyre</strong></p></div>
        <div class="hero-actions"><button class="primary" id="startBtn">▶ Start Cycle</button><button class="secondary" id="pauseBtn">Ⅱ Pause</button><button class="secondary" id="homeBtn">⌂ Home Gantry</button></div>
      </section>

      <section class="kpi-grid">
        <article class="kpi"><span>Cycle Time</span><strong id="cycleTime">28.0 s</strong><small>Target per tyre</small></article>
        <article class="kpi"><span>Completed</span><strong id="completed">0 / 80</strong><small id="completedPct">0% of pallet plan</small></article>
        <article class="kpi"><span>Current Pallet</span><strong id="currentPallet">Pallet 1</strong><small id="currentPosition">Row 1 · Tyre 1</small></article>
        <article class="kpi"><span>Machine State</span><strong id="machineState">READY</strong><small id="machineDetail">Waiting for start</small></article>
      </section>

      <section class="workspace">
        <div class="scene-card">
          <div class="card-head"><div><h2>Live 3D Cell</h2><span>Concept based on X / Y / Z gantry movement</span></div><div class="camera-tools"><button data-camera="iso">ISO</button><button data-camera="top">TOP</button><button data-camera="front">FRONT</button></div></div>
          <div id="scene" class="scene"></div>
          <div class="scene-footer"><span><b class="dot blue"></b>X axis: bridge travel</span><span><b class="dot purple"></b>Y axis: cross travel</span><span><b class="dot orange"></b>Z axis: pick/place</span><span><b class="dot green"></b>Gripper</span></div>
        </div>
        <aside class="control-card">
          <div class="card-head"><div><h2>Motion Controller</h2><span>Live commanded position</span></div><span class="live-tag">LIVE</span></div>
          <div class="axis"><div><span>X Axis</span><b id="xValue">0 mm</b></div><input id="xSlider" type="range" min="-8" max="8" step="0.1" value="0"></div>
          <div class="axis"><div><span>Y Axis</span><b id="yValue">0 mm</b></div><input id="ySlider" type="range" min="-5" max="5" step="0.1" value="0"></div>
          <div class="axis"><div><span>Z Axis</span><b id="zValue">2.8 mm</b></div><input id="zSlider" type="range" min="0.2" max="4" step="0.1" value="2.8"></div>
          <div class="grip-state"><span>Gripper</span><button id="gripBtn">OPEN</button></div>
          <div class="progress-wrap"><div><span>Current cycle</span><b id="cycleProgressText">0%</b></div><div class="progress"><i id="cycleProgress"></i></div></div>
        </aside>
      </section>

      <section class="lower-grid">
        <div class="pallet-card"><div class="card-head"><div><h2>Pallet Occupancy</h2><span>4 pallets · 20 positions each</span></div><button class="secondary" id="clearBtn">Clear Demo</button></div><div id="palletGrid" class="pallet-grid"></div></div>
        <div class="log-card"><div class="card-head"><div><h2>Cycle Log</h2><span>Most recent machine events</span></div><button class="secondary" id="downloadLog">Export</button></div><div id="eventLog" class="event-log"></div></div>
      </section>
    </main>
  </div>`;
}
