# Picker & Placer 3D Gantry Dashboard

A Vite + JavaScript + Three.js dashboard for a 4-pallet tyre picker/placer concept.

## Cell assumptions implemented
- 4 pallets
- 4 rows per pallet
- 5 tyre columns per row
- 20 tyre positions per pallet / 80 total positions
- Target cycle time: 28.0 seconds per tyre
- X/Y/Z gantry visualization with a bridge, cross rail, vertical Z carriage and gripper
- Start, pause, home, reset, gripper, camera presets and cycle-log export

## Run in VS Code
1. Open this folder in VS Code.
2. Open Terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL printed by Vite.

## Structure
- `src/main.js` – app bootstrap
- `src/modules/dashboard.js` – dashboard UI markup
- `src/modules/gantryScene.js` – Three.js 3D cell
- `src/modules/cycleController.js` – 28-second sequence and UI state
- `src/styles/main.css` – responsive dark industrial UI
- `public/reference/` – supplied system image and rendered PDF reference

## Source note
The uploaded gantry PDF was treated as a conceptual reference. Its BOM identifies an EGC-TB toothed-belt axis, an EGC-BS spindle axis, Y/Z adapter plates, servo motors, proximity sensors, and a parallel gripper/rotary-gripper unit. The PDF also states that the GA drawing is conceptual and dimensions are in mm; therefore this dashboard is a visualization/prototype, not a production-certified mechanical drawing.
